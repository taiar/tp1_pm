package Utilitarios;

/**
 * Excecao que e lancada quando ocorre a tentativa de acesso a uma chave
 * inexistente no Dicionario
 */
public class ExcecaoChaveInexistente extends Exception {

}
