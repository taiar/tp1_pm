Nomes da dupla:
1. André Taiar Marinho Oliveira
2. Gustavo Henrique Alves Pereira